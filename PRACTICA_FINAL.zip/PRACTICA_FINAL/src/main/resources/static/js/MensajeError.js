//el código JavaScript se esté ejecutando antes de que el HTML esté completamente cargado.
window.addEventListener('load', function() {
  var urlParams = new URLSearchParams(window.location.search);
  var message = urlParams.get('message');
  var errorType = urlParams.get('errorType');

  if (message === "error") {
      if (errorType === "email") {
          alert("El email ingresado ya existe. Por favor, intente con un email diferente.");
      } else if(errorType === "session_already_active") {
          alert("Ya hay un inicio de sesión. Por favor, cierre la otra sesión.");
      } else if (errorType === "adm") {
          alert("Zona privada para el administrador");
      }else {
          alert("Ha ocurrido un error al registrarse. Por favor, intente de nuevo más tarde.");
      }
  } else if (message === 'logout') {
      alert("Sesión cerrada");
  } else if (message === "success") {
      alert("Operación realizada con éxito (Registro / Inicio Sesión finalizado)");
  } else if (message === "registro") {
      alert("Debes estar registrado para poner una reseña, por favor, regístrate o inicia sesión");
  }
  else if (message === "administrador") {
      alert("Esta no es la sección de administrador");
  }
});
