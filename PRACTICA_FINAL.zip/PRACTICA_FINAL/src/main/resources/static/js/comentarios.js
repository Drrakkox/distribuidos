//EXTERIORES
    // Obtener el botón "Agregar comentario"
    var agregarComentarioBtn = document.querySelector("#myModal button#agregarComentarioBtn");

    // Obtener el input de nombre
    var nombreInput = document.querySelector("#myModal input#nombre");

    // Obtener el input de comentario
    var comentarioInput = document.querySelector("#myModal input#coment");

    // Obtener el contenedor de comentarios
    var comentariosContainer = document.querySelector("#comentariosContainer");

    // Deshabilitar el botón "Agregar comentario" por defecto
    agregarComentarioBtn.disabled = true;

    // Agregar un manejador de eventos input al input de comentario para habilitar/deshabilitar el botón "Agregar comentario"
    comentarioInput.addEventListener("input", function() {
      agregarComentarioBtn.disabled = comentarioInput.value === "";
    });

    // Agregar un manejador de eventos click al botón "Agregar comentario"
    agregarComentarioBtn.addEventListener("click", function() {
      // Obtener los valores del input de nombre y del input de comentario
      var nombre = nombreInput.value;
      var comentario = comentarioInput.value;

      // Verificar si el campo de nombre está vacío, y establecer el valor de nombre como "Anónimo" si es así
      if (nombre === "") {
        nombre = "Anónimo";
      }

      // Crear un elemento HTML para mostrar el comentario con el nombre
      var comentarioElement = document.createElement("p");
      comentarioElement.textContent = nombre + ": " + comentario;

      // Agregar el elemento HTML al contenedor de comentarios
      comentariosContainer.appendChild(comentarioElement);

      // Limpiar los inputs de nombre y comentario
      nombreInput.value = "";
      comentarioInput.value = "";

      // Deshabilitar el botón "Agregar comentario" después de agregar el comentario
      agregarComentarioBtn.disabled = true;
    });