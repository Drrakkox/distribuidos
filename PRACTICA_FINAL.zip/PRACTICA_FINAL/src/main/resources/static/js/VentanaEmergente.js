//PRIEMRA EMERGENTE
    // Obtener el botón que abre la ventana emergente
    var btn = document.querySelector(".modal-button");

    // Obtener la ventana emergente
    var modal = document.getElementById("myModal");

    // Obtener el botón para cerrar la ventana emergente
    var span = document.getElementsByClassName("close")[0];

    // Cuando el usuario hace clic en el botón, abrir la ventana emergente
    btn.onclick = function() {
      modal.style.display = "block";
    }

    // Cuando el usuario hace clic en la X, cerrar la ventana emergente
    span.onclick = function() {
      modal.style.display = "none";
    }

    // Cuando el usuario hace clic fuera de la ventana emergente, cerrarla
    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }

