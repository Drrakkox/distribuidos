package urjc.code.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
@RequestMapping("/api/users")
public class UserRESTController {

    @Autowired
    private UserService userService;
    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestParam("email") String email, @RequestParam("password") String password, HttpServletRequest request) {
        User user = userService.authenticateUser(email, password);
        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("email", email);
            return ResponseEntity.ok("Usuario autenticado");
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Usuario o contraseña incorrectos");
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User newUser) {
        if (newUser.getEmail().equals("admin@admin.com")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No puedes usar el correo electrónico de administrador");
        }
        if (newUser.getPassword().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("La contraseña no puede estar vacía");
        }

        if (userService.registrarUsuario(newUser)) {
            return ResponseEntity.status(HttpStatus.CREATED).body("Usuario registrado correctamente");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error al registrar el usuario");
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return ResponseEntity.ok("Sesión cerrada");
    }

    @GetMapping("/usuarios")
    public ResponseEntity<?> showUserList(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No autorizado");
        }

        String email = (String) session.getAttribute("email");
        if (!userService.isAdmin(email)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No autorizado");
        }

        Collection<User> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }

    @PutMapping("/todosusuarios")
    public ResponseEntity<String> updateUser(@RequestBody UserUpdateRequest request) {
        if (userService.updateUser(request.getOriginalEmail(), request.getNewEmail(), request.getNewPassword(), request.getNewRole())) {
            return ResponseEntity.ok("Usuario actualizado");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al actualizar el usuario");
        }
    }
}