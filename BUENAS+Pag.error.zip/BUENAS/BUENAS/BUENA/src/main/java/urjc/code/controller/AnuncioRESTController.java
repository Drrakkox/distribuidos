package urjc.code.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequestMapping("/api/")
@RestController
public class AnuncioRESTController {
    @Autowired
    AnuncioService anuncioService;
    UserService userService;

    @PostMapping("/addLike/{id}/")
    public ResponseEntity<Map<String, Object>> addLike(@PathVariable Long id) {
        Anuncio anuncio = anuncioService.getAnuncio(id);
        Map<String, Object> response = new HashMap<>();
        if(anuncio == null){
            response.put("mensaje", "No se ha podido agregar un like al anuncio con ID " + id);
            return ResponseEntity.badRequest().body(response);
        }
        anuncioService.addLike(id);
        response.put("likes", anuncio.getLikes());
        response.put("mensaje", "Like agreagado al anuncio con ID " + id + " correctamente");
        return ResponseEntity.ok().body(response);
    }

    @GetMapping("/anuncios")
    public ResponseEntity<?> getAll() {
        return ResponseEntity.ok(anuncioService.getAll());
    }

    @PostMapping("/anuncios")
    public ResponseEntity<?> createAnuncio(HttpServletRequest request, @RequestBody Anuncio anuncio) {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("email") != null) {
            anuncioService.createAnuncio(anuncio);
            return ResponseEntity.status(HttpStatus.CREATED).body(anuncio);
        } else {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Debes iniciar sesión para crear un anuncio");
        }
    }


    @DeleteMapping("/anuncios/{id}")
    public ResponseEntity<String> deleteAnuncio(@PathVariable Long id, @RequestParam("userEmail") String userEmail) {
        Anuncio anuncio = anuncioService.getAnuncio(id);

        if (anuncio != null) {
            if (anuncio.getEmail().equals(userEmail) || userService.isAdmin(userEmail)) {
                anuncioService.deleteAnuncio(id);
                return ResponseEntity.ok("Anuncio eliminado");
            }
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Anuncio no encontrado");
    }

}
