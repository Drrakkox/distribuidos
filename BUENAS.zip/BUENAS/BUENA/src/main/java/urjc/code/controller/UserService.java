package urjc.code.controller;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class UserService {

    @Autowired
    FakeDataBase database;

    @PostConstruct
    public void initAdminUser() {
        if (database.getUserByEmail("admin@admin.com") == null) {
            User admin = new User("admin@admin.com", "admin", "admin");
            database.addUser(admin);
        }
    }

    public User getUserByEmail(String email) {
        return database.getUserByEmail(email);
    }

    public Boolean addUser(User usuario) {
        return database.addUser(usuario);
    }

    public boolean registrarUsuario(User userModel) {
        return database.addUser(userModel);
    }

    public User authenticateUser(String email, String password) {
        return database.authenticateUser(email, password);
    }

    public Collection<User> getAllUsers() {
        return database.getAllUsers();
    }

    public boolean isAdmin(String email) {
        User user = database.getUserByEmail(email);
        boolean isAdmin = user != null && user.getRole().equals("admin");

        System.out.println("Is admin: " + isAdmin); // Añade esta línea para depurar

        return isAdmin;
    }
    public boolean updateUser(String originalEmail, String newEmail, String newPassword, String newRole) {
        User user = database.getUserByEmail(originalEmail);
        if (user != null) {
            user.setEmail(newEmail);
            user.setPassword(newPassword);
            user.setRole(newRole);
            database.updateUser(originalEmail, user);
            return true;
        }
        return false;
    }
}
