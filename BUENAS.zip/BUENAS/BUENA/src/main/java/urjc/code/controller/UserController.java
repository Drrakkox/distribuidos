package urjc.code.controller;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/IniciarSesion")
    public String CuentasUsuarioAdmin(Model model) {
        return "CuentasUsuarioAdmin.html";
    }

    @PostMapping("/login/")
    public String loginUser(@RequestParam("email") String email, @RequestParam("password") String password, HttpServletRequest request, Model model) {
        User user = userService.authenticateUser(email, password);
        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("email", email);
            return "redirect:/index.html?message=success&email=" + email;
        }
        return "redirect:/CuentasUsuarioAdmin.html?message=error";
    }

    @PostMapping("/register/")
    public String register(@RequestParam String email, @RequestParam String password, @RequestParam(required = false, defaultValue = "user") String role, HttpServletRequest request) {

        if (email.equals("admin@admin.com")) {
            return "redirect:/CuentasUsuarioAdmin.html?message=administrador";
        }
        if (password.isEmpty()) {
            return "redirect:/CuentasUsuarioAdmin.html?message=ps";
        }

        User newUser = new User(email, password, role);

        if (userService.registrarUsuario(newUser)) {
            HttpSession session = request.getSession();
            session.setAttribute("email", email);
            return "redirect:/index.html?message=success";
        } else {
            return "redirect:/CuentasUsuarioAdmin.html?message=error&errorType=email";
        }
    }


    @PostMapping("/logout/")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return "redirect:/index.html?message=logout";
    }
    @GetMapping("/usuarios")
    public ResponseEntity<?> showUserList(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session == null) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No autorizado");
        }

        String email = (String) session.getAttribute("email");
        if (!userService.isAdmin(email)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("No autorizado");
        }

        Collection<User> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }
    @PutMapping("/todosusuarios")
    public ResponseEntity<String> updateUser(@RequestBody UserUpdateRequest request) {
        if (userService.updateUser(request.getOriginalEmail(), request.getNewEmail(), request.getNewPassword(), request.getNewRole())) {
            return ResponseEntity.ok("Usuario actualizado");
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al actualizar el usuario");
        }
    }
}
