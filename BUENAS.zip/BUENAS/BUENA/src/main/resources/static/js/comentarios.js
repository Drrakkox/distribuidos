//EXTERIORES
    // Obtener el botón "Agregar comentario"
    var agregarComentarioBtn = document.querySelector("#myModal button#agregarComentarioBtn");

    // Obtener el input de nombre
    var nombreInput = document.querySelector("#myModal input#nombre");

    // Obtener el input de comentario
    var comentarioInput = document.querySelector("#myModal input#coment");

    // Obtener el contenedor de comentarios
    var comentariosContainer = document.querySelector("#comentariosContainer");

    // Deshabilitar el botón "Agregar comentario" por defecto
    agregarComentarioBtn.disabled = true;

    // Agregar un manejador de eventos input al input de comentario para habilitar/deshabilitar el botón "Agregar comentario"
    comentarioInput.addEventListener("input", function() {
      agregarComentarioBtn.disabled = comentarioInput.value === "";
    });

    // Agregar un manejador de eventos click al botón "Agregar comentario"
    agregarComentarioBtn.addEventListener("click", function() {
      // Obtener los valores del input de nombre y del input de comentario
      var nombre = nombreInput.value;
      var comentario = comentarioInput.value;

      // Verificar si el campo de nombre está vacío, y establecer el valor de nombre como "Anónimo" si es así
      if (nombre === "") {
        nombre = "Anónimo";
      }

      // Crear un elemento HTML para mostrar el comentario con el nombre
      var comentarioElement = document.createElement("p");
      comentarioElement.textContent = nombre + ": " + comentario;

      // Agregar el elemento HTML al contenedor de comentarios
      comentariosContainer.appendChild(comentarioElement);

      // Limpiar los inputs de nombre y comentario
      nombreInput.value = "";
      comentarioInput.value = "";

      // Deshabilitar el botón "Agregar comentario" después de agregar el comentario
      agregarComentarioBtn.disabled = true;
    });

    // Agregar comentarios predeterminados al contenedor de comentarios
    var comentarioElement1 = document.createElement("p");
    comentarioElement1.textContent = "Anónimo: Son muy bonitas y originales";
    comentariosContainer.appendChild(comentarioElement1);

    var comentarioElement2 = document.createElement("p");
    comentarioElement2.textContent = "Noemi: Sirven como inspiración para futuros proyectos. Gracias!.";
    comentariosContainer.appendChild(comentarioElement2);

    var comentarioElement1 = document.createElement("p");
    comentarioElement1.textContent = "Pedro: Profesionlidad y competencia";
    comentariosContainer.appendChild(comentarioElement1);

    var comentarioElement1 = document.createElement("p");
    comentarioElement1.textContent = "Anónimo: Son proyectos únicos y que te permiten expresar tus gustos e ideas";
    comentariosContainer.appendChild(comentarioElement1);

    var comentarioElement1 = document.createElement("p");
    comentarioElement1.textContent = "Elisa: Gran visión de futuro y profesionalidad";
    comentariosContainer.appendChild(comentarioElement1);

    var comentarioElement1 = document.createElement("p");
    comentarioElement1.textContent = "Javier: Me encantan las fotos!!";
    comentariosContainer.appendChild(comentarioElement1);

    var comentarioElement1 = document.createElement("p");
    comentarioElement1.textContent = "Pedro: ¡Excelente trabajo con la pagina web! Muy original y funcional";
    comentariosContainer.appendChild(comentarioElement1);